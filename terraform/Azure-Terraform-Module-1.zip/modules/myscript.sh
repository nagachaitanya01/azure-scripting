#!/bin/bash
apt update -y
apt install -y git nginx tree unzip
service nginx start